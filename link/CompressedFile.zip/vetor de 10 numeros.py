"""Faça um Programa que leia um vetor de 10 números reais e mostre-os na ordem inversa."""

lista = []

for lista in range(11):
    lista.append(lista)

print(var)
