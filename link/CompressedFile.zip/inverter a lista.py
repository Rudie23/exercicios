lista = []

for _ in range(5):
    numero = int(input('Digite um número inteiro: '))
    lista.append(numero)

lista.reverse()
print(lista)