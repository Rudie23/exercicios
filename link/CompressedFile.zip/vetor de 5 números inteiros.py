"""Programa para pôr valores em uma lista(vetor)"""
lista = list(range(1, 11))

print(sorted(lista, reverse=True))
